-- Drop the orderdetails table with CASCADE option
DROP TABLE IF EXISTS orderdetails CASCADE;

-- Drop the orders table with CASCADE option
DROP TABLE IF EXISTS orders CASCADE;

-- Drop the customers table with CASCADE option
DROP TABLE IF EXISTS customers CASCADE;

-- Drop the books table
DROP TABLE IF EXISTS books;

-- Recreate the books table
CREATE TABLE books (
    isbn VARCHAR(13),
    title VARCHAR(50),
    author VARCHAR(50),
    genre VARCHAR(50),
    price VARCHAR(50),
    stockquantity INT
);

INSERT INTO books (isbn, title, author, genre, price, stockquantity) VALUES 
    ('912086008-0', 'Cincinnati Bell Inc', 'Sherm Haill', 'Crime|Mystery|Thriller', '$16.96', 23),
    ('003236704-X', 'National CineMedia, Inc.', 'Doralynn Colvie', 'Horror', '$29.17', 21),
    ('808860727-2', 'Equinix, Inc.', 'Netti Mulvany', 'Drama', '$28.37', 25),
    ('216989339-3', 'Lam Research Corporation', 'Hodge Leversha', 'Drama', '$13.92', 35),
    ('371476592-1', 'Viking Therapeutics, Inc.', 'Leonelle Brothwell', 'Action|Drama|Thriller', '$18.27', 34);

-- Recreate other tables similarly
CREATE TABLE customers (
    customerid INT,
    name VARCHAR(50),
    email VARCHAR(50),
    phone VARCHAR(50),
    address VARCHAR(50)
);

INSERT INTO customers (customerid, name, email, phone, address) VALUES 
    (59, 'Alica Matyushonok', 'amatyushonok0@ucoz.com', '970-834-9108', '021 Lighthouse Bay Center'),
    (1, 'Tessie Gagin', 'tgagin1@taobao.com', '925-358-9885', '273 Manitowish Place'),
    (30, 'Bernadine Hutchence', 'bhutchence2@shutterfly.com', '943-495-0343', '33 Darwin Lane'),
    (94, 'Gaylord Tsarovic', 'gtsarovic3@wufoo.com', '625-295-5330', '2 Graedel Parkway'),
    (32, 'Marsiella Russo', 'mrusso4@123-reg.co.uk', '710-482-7413', '579 Debs Court');

CREATE TABLE orders (
    orderid INT,
    customerid INT,
    orderdate DATE,
    totalprice VARCHAR(50)
);

INSERT INTO orders (orderid, customerid, orderdate, totalprice) VALUES 
    (6, 59, '4/2/2023', '$14.44'),
    (68, 1, '4/30/2023', '$2.47'),
    (94, 30, '8/16/2023', '$26.53'),
    (34, 32, '6/29/2023', '$1.63'),
    (32, 94, '2/20/2023', '$5.13');

CREATE TABLE orderdetails (
    orderid INT,
    orderdetailid INT,
    isbn VARCHAR(50),
    quantity INT
);

INSERT INTO orderdetails (orderid, orderdetailid, isbn, quantity) VALUES 
    (6, 91, '912086008-0', 7),
    (68, 18, '003236704-X', 12),
    (94, 67, '808860727-2', 9),
    (34, 1, '216989339-3', 15),
    (32, 94, '371476592-1', 19);