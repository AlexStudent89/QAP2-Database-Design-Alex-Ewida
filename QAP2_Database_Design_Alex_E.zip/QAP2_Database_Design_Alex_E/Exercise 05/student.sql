DROP TABLE IF EXISTS student;
create table student (
	studentId INT,
	studentName VARCHAR(50),
	birthdate DATE,
	grade INT
);
insert into student (studentId, studentName, birthdate, grade) values (45, 'Oberon Bigby', '9/29/2012', 12);
insert into student (studentId, studentName, birthdate, grade) values (37, 'Randall McClements', '2/2/2013', 11);
insert into student (studentId, studentName, birthdate, grade) values (98, 'Carlo Blaksley', '2/25/2014', 10);
insert into student (studentId, studentName, birthdate, grade) values (53, 'Somerset Pomeroy', '3/30/2015', 9);
insert into student (studentId, studentName, birthdate, grade) values (36, 'Morena Guiel', '1/26/2016', 8);
insert into student (studentId, studentName, birthdate, grade) values (78, 'Waldon Klimuk', '10/12/2017', 7);
insert into student (studentId, studentName, birthdate, grade) values (48, 'Tabbi McMenamie', '2/7/2018', 6);
insert into student (studentId, studentName, birthdate, grade) values (35, 'Ludvig Legon', '3/27/2019', 5);

