DROP TABLE IF EXISTS class;
create table class (
	classid INT,
	classname VARCHAR(50)
);
insert into class (classid, classname) values (78, 'Help Desk Technician');
insert into class (classid, classname) values (25, 'Senior Cost Accountant');
insert into class (classid, classname) values (44, 'Geological Engineer');
insert into class (classid, classname) values (89, 'Budget/Accounting Analyst IV');
insert into class (classid, classname) values (5, 'Budget/Accounting Analyst III');
insert into class (classid, classname) values (27, 'Assistant Media Planner');
insert into class (classid, classname) values (65, 'Software Consultant');
insert into class (classid, classname) values (74, 'Web Designer IV');
