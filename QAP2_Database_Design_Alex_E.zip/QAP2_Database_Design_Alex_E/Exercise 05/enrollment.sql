DROP TABLE IF EXISTS enrollment;
create table enrollment (
	enrollmentid INT,
	studentid INT,
	classid INT,
	final_grade INT
);
insert into enrollment (enrollmentid, studentid, classid, final_grade) values (80, 45, 78, 9);
insert into enrollment (enrollmentid, studentid, classid, final_grade) values (64, 37, 25, 13);
insert into enrollment (enrollmentid, studentid, classid, final_grade) values (45, 98, 44, 34);
insert into enrollment (enrollmentid, studentid, classid, final_grade) values (23, 53, 89, 43);
insert into enrollment (enrollmentid, studentid, classid, final_grade) values (100, 36, 5, 51);
insert into enrollment (enrollmentid, studentid, classid, final_grade) values (43, 78, 27, 63);
insert into enrollment (enrollmentid, studentid, classid, final_grade) values (52, 48, 65, 84);
insert into enrollment (enrollmentid, studentid, classid, final_grade) values (7, 35, 74, 33);
