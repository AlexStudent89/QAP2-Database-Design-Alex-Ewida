DROP TABLE IF EXISTS province;

CREATE TABLE province (
    provinceid INT,
    provincename VARCHAR(50),
    capitalcityid VARCHAR(50),
    population INT,
    area VARCHAR(50)
);

INSERT INTO province (provinceid, provincename, capitalcityid, population, area) VALUES
(38, 'Ontario', '1', 32710, 47.8313394),
(43, 'Florida', '5', 93374, 25.7564471),
(60, 'Quebec', '4', 24740, 22.4410669),
(70, 'Nova Scotia', '2', 60795, 6.6169319),
(24, 'New Brunswick', '3', 79567, 30.7446878);