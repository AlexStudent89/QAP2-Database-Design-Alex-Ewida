DROP TABLE IF EXISTS city;
create table city (
	cityid INT,
	cityname VARCHAR(50),
	population INT,
	foundeddate DATE,
	landarea VARCHAR(50),
	provinceid INT
);
insert into city (cityid, cityname, population, foundeddate, landarea, provinceid) values (1, 'Torres', 1357, '8/23/1996', -49.723909, 38);
insert into city (cityid, cityname, population, foundeddate, landarea, provinceid) values (2, 'Makubetsu', 3247, '3/7/2022', 141.82111, 70);
insert into city (cityid, cityname, population, foundeddate, landarea, provinceid) values (3, 'Lubowidz', 4271, '4/12/1982', 19.8841425, 24);
insert into city (cityid, cityname, population, foundeddate, landarea, provinceid) values (4, 'Gur’yevsk', 6041, '10/20/2003', 85.797215, 60);
insert into city (cityid, cityname, population, foundeddate, landarea, provinceid) values (5, 'Vagney', 4596, '11/29/2009', 6.7166698, 43);